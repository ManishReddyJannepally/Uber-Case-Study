# set working directory
# Clearning all existing variables
rm(list = ls())
# list files to ensure dataset is available
list.files()

# loading required libraries
library(tidyr)
library(dplyr)
library(stringr)
library(ggplot2)
library(lubridate)
library(corrplot)
library(ggrepel)
# library(PerformanceAnalytics)

# ------------------------------------------ Load Source Data ------------------------------------------------
loan <- read.csv("loan.csv", stringsAsFactors = FALSE)
str(loan)
ncol(loan) # 111 variables
nrow(loan) # 39717 rows
sum(colSums(is.na(loan))!=nrow(loan)) 
# 57 columns have some values and are not complete NA

#------------------------------------------- Data Cleaning -----------------------------------------------------

# Removing columns which have all values as NA
length(unique(na.omit(loan1)))
loan1 <- loan[, colSums(is.na(loan)) != nrow(loan)]
ncol(loan1) #57 Variables
str(loan1)

# Removing all the columns with only 1 unique value other than NA
loan2 <- Filter(function(x)(length(unique(na.omit(x)))>1), loan1)

colSums(is.na(loan2))
NA_percent = sapply(loan2,function(x){ round(sum(is.na(x))/length(x)*100,2)})
NA_percent # mths_since_last_record has 93% of missing values and mths_since_last_delinq has 65%.

# emp_length has NAs but they are mentioned as n/a
loan2$emp_length[loan2$emp_length == "n/a"] = NA
sum(is.na(loan2$emp_length))
# emp_length is a categorical column. We chose to impute them with mode of the column because losing 1075 rows results information loss.

mode <- function(x, na.rm = FALSE) { # custom function for mode
  if(na.rm){
    x = x[!is.na(x)]
  }
  ux <- unique(x)
  return(ux[which.max(tabulate(match(x, ux)))])
}


mode(loan2$emp_length) # mode for the emp_length column

loan2$emp_length[is.na(loan2$emp_length)] = mode(loan2$emp_length)

sum(is.na(loan2$emp_length))

str(loan2)
summary(loan2)

# Checking if there are duplicate ids or member id
sum(duplicated(loan2$id))
sum(duplicated(loan2$member_id))
# No duplicate records found

# Based on analysis done from summary and details captured from received Data Dictionary, we believe following
# columns are not required to solve the business case. Hence, deleting these columns from the given dataset.

# Application name is already existing in another column
loan2$url <- NULL 
# This is giving the profile / loan requirement. It is a free text field, hence deleting this.
loan2$desc <- NULL
# This contain various details and is not appropriately structured, hence deleting this value.
loan2$title <- NULL 
# This contain various details and is not appropriately structured, hence deleting this value.
loan2$emp_title <- NULL 
#loan2$total_rec_late_fee <- NULL # Data given in this column is mostly 0, with very few values, hence may not be much useful in creating the model
#loan2$collection_recovery_fee <- NULL # This has very limited data and may not be useful in appropriate analysis
# This is date for future payments and is not required to analyse historic trend.
loan2$next_pymnt_d <- NULL 

# converting variables into factor to use them as categorical variable
loan2$term <- as.factor(loan2$term)
loan2$grade <- as.factor(loan2$grade)
loan2$sub_grade <- as.factor(loan2$sub_grade)
loan2$emp_length <- as.factor(loan2$emp_length)
loan2$home_ownership <- as.factor(loan2$home_ownership)
loan2$verification_status <- as.factor(loan2$verification_status)
loan2$loan_status <- as.factor(loan2$loan_status)
loan2$zip_code <- as.factor(loan2$zip_code)
loan2$addr_state <- as.factor(loan2$addr_state)

# Cleaning variables and converting them to factor or numeric to use them appropriately

loan2$int_rate <- gsub("%","",loan2$int_rate,ignore.case = FALSE, fixed = FALSE)
loan2$int_rate <- as.numeric(loan2$int_rate)
loan2$revol_util <- gsub("%","",loan2$revol_util,ignore.case = FALSE, fixed = FALSE)
loan2$revol_util <- as.numeric(loan2$revol_util)


# Converting dates into R compatible format and deriving months (Used Lubridate package and library)
loan2$issue_d <- parse_date_time(loan2$issue_d, c("%b-%y"))
loan2$last_pymnt_d <- parse_date_time(loan2$last_pymnt_d, c("%b-%y"))
loan2$earliest_cr_line <- parse_date_time(loan2$earliest_cr_line, c("%b-%y"))
loan2$last_credit_pull_d <- parse_date_time(loan2$last_credit_pull_d, c("%b-%y"))

# Identifying Outliers
Outlier_perc <- function(x){
caps <- quantile(as.numeric(x), probs=c(.01, .99), na.rm = TRUE)
x<- na.omit(x)
perc <- round(length(x[x < as.numeric(caps[1]) | x > as.numeric(caps[2])])/nrow(loan2),2)*100
}

numeric_variables <- c("loan_amnt","funded_amnt","funded_amnt_inv","int_rate","installment","annual_inc","dti","delinq_2yrs","inq_last_6mths","mths_since_last_delinq","mths_since_last_record","open_acc","pub_rec","revol_bal","revol_util","total_acc","out_prncp","out_prncp_inv","total_pymnt","total_pymnt_inv","total_rec_prncp","total_rec_int","total_rec_late_fee","recoveries","collection_recovery_fee","last_pymnt_amnt","pub_rec_bankruptcies")
sapply(loan2[,numeric_variables], function(x) Outlier_perc(as.numeric(x)))
# Maximum 2% values are less than 1 percentile or greater than 99 percentile.

# -------------------------------------- Derived Metrics ------------------------------------------------------

# Following are the calculated values to help us know the loss or profit to the bank
loan2$duration_val <- gsub(" months","",loan2$term, fixed = FALSE)
loan2$duration_val <- as.numeric(loan2$duration_val)
loan2$gap <- loan2$total_pymnt - loan2$funded_amnt
loan2$gap_inv <- loan2$total_pymnt_inv - loan2$funded_amnt_inv
loan2$expected_maturity_amount <- loan2$funded_amnt + (loan2$funded_amnt * loan2$int_rate * (loan2$duration_val/12))
loan2$expected_maturity_amount_inv <- loan2$funded_amnt_inv + (loan2$funded_amnt_inv * loan2$int_rate * loan2$duration_val/12 )
summary(loan2)

# Computed variables to know the status
Bank_profit <- sum(loan2$gap)
Inv_profit <- sum(loan2$gap_inv)
Bank_profit # Bank had total profit of 47.89 M
Inv_profit # Investors had total profit of 46.45 M

# Actual profit earned by Bank
expected_profit = sum(loan2$expected_maturity_amount - loan2$funded_amnt)
expected_profit # 21.5 Billion

# Actual profit earned by investers
expected_profit_inv = sum(loan2$expected_maturity_amount_inv - loan2$funded_amnt_inv)
expected_profit_inv # 20.6 Billion

# Target variable
loan2$defaulted <- ifelse(loan2$loan_status == "Charged Off", 1, 0)

# Computing few additional matrix based on domain knowledge
loan2$monthly_income <- loan2$annual_inc/12
loan2$income_install_ratio <- loan2$installment/loan2$monthly_income
summary(loan2$income_install_ratio)

# --------------------------------------- Exploratory Data Analysis --------------------------------------------

# Correlation between variables
loan_quantitative <- loan2[,c("loan_amnt","funded_amnt","funded_amnt_inv","int_rate","installment","annual_inc","dti","delinq_2yrs","inq_last_6mths","mths_since_last_delinq","mths_since_last_record","open_acc","pub_rec","revol_bal","revol_util","total_acc","out_prncp","out_prncp_inv","total_pymnt","total_pymnt_inv","total_rec_prncp","total_rec_int","total_rec_late_fee","recoveries","collection_recovery_fee","last_pymnt_amnt","pub_rec_bankruptcies","expected_maturity_amount","expected_maturity_amount_inv","defaulted")]
corr = cor(loan_quantitative, use ='pairwise.complete.obs')
View(corr)
corrplot(corr,  type = "upper",tl.col = "black", tl.cex = 0.7)
# Below code is more helpful to analyse the correlation better but is taking lot of time to plot the graph
# chart.Correlation(loan_quantitative, histogram=TRUE, pch=19)
# Positive correlation is identified between loan amount, funded amount, funded_amount_inv, installments, and income.
# Negative correction is identified between loan amount and pub_rec_bankruptcies, delinq_2yrs and pub_rec


# Creating the groups or slots of some of the variables like Loan Amount, Interest rate and employee income
quantile(loan2$loan_amnt, seq(0,1,0.2))
loan2$loan_amount_slot = ifelse(loan2$loan_amnt < 5000, "Less than 5000", ifelse(loan2$loan_amnt < 8000,"5K to 8k",ifelse(loan2$loan_amnt < 12000,"8K to 12k",ifelse(loan2$loan_amnt < 20000,"12K to 20k","more than 20K"))))
quantile(loan2$int_rate, seq(0,1,0.2))
loan2$int_rate_slot = ifelse(loan2$int_rate < 8, "Less than 8%", ifelse(loan2$int_rate < 11,"8% to 11", ifelse(loan2$int_rate < 13,"11% to 13%",ifelse(loan2$int_rate < 16,"13% to 16%","more than 16%"))))
quantile(loan2$annual_inc, seq(0,1,0.2))
loan2$annual_inc_slot = ifelse(loan2$annual_inc < 25000, "Less than 25k", ifelse(loan2$annual_inc < 50000,"25K to 50K", ifelse(loan2$annual_inc < 75000,"50K to 75k",ifelse(loan2$annual_inc < 100000,"75K to 100K","more than 100K"))))

# Plot some graphs for analysis

ggplot(loan2, aes(x = as.factor(loan2$loan_status)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Loan Status", y = "Count of Loan Applications") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)

length(which(loan2$loan_status == "Charged Off")) / nrow(loan2) # 14.16% of loan is getting charged off

loan_chargedoff <- subset(loan2, loan$loan_status == "Charged Off") # Dataset with only charged off data
loan_fullypaid <- subset(loan2, loan$loan_status == "Fully Paid") # # Dataset with only Fully Paid Loan data

# Computed variables to know the status
Bank_profit <- sum(loan_chargedoff$gap)
Inv_profit <- sum(loan_chargedoff$gap_inv)
Bank_profit # Bank had loss of 27.65 M Due to defaulters
Inv_profit # Investors had loss of 25.3 M Due to defaulters

summary(loan_chargedoff$loan_amnt)
summary(loan_fullypaid$loan_amnt)
summary(loan_chargedoff$income_install_ratio)
summary(loan_fullypaid$income_install_ratio)
ggplot(loan2, aes(x = loan_status, y=loan_amnt)) + geom_boxplot(outlier.colour="red",outlier.size=1)+ labs(x = "Loan Status", y = "Loan Amount")
ggplot(loan2, aes(x = loan_status, y=income_install_ratio)) + geom_boxplot(outlier.colour="red",outlier.size=1)+ labs(x = "Loan Status", y = "Income to Installment Ratio")
# This shows that applicants with higher Income to Installment ratio are liable to default the loan

summary(loan_chargedoff$int_rate)
summary(loan_fullypaid$int_rate)
ggplot(loan2, aes(x = loan2$loan_status, y=int_rate)) + geom_boxplot(outlier.colour="red",outlier.size=1)+ labs(x = "Loan Status", y = "Interest Rate")
# This shows that applicants with higher interest rate are liable to default the loan while it is also observed that in progress loan have even higher interest rate and hence more sustable to be loan defaulters

# Let us do some univariate analysis on categorical variables
ggplot(loan_chargedoff, aes(x = as.factor(term)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Loan Term", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
3227/5627 # loan defaulters with 36 months term (57.35%)
2400/5627 # loan defaulters with 60 months term (42.65%)

ggplot(loan_chargedoff, aes(x = as.factor(verification_status)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Verification Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
2142/5627 #38% of loan defaulters were not verified
2051/5627 #36.4% of loan defaulters were verified - This clearly shows that bank has to improve on their verification process

ggplot(loan_chargedoff, aes(x = as.factor(home_ownership)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Home Ownership", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
2839/5627 #50.4% of loan defaulters are staying on rent
2327/5627 #41.4% of loan defaulters have their home mortgage

ggplot(loan_chargedoff, aes(x = as.factor(grade)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Grade", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
1425/5627 #25.32% of loan defaulters are in Grade B

ggplot(loan_chargedoff, aes(x = as.factor(emp_length)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Employee Length", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
1559/5627 #27.71% of loan defaulters have emp_lenth > 10 years. This include application count with n/a category mentioned

ggplot(loan_chargedoff, aes(x = as.factor(purpose)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Purpose", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)+ theme(text = element_text(size=10), axis.text.x = element_text(angle=45, hjust=1))
2767/5627 #49.17% of loan defaulters have taken loan for debt_consolidation

ggplot(loan_chargedoff, aes(x = as.factor(addr_state)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "State Address", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)+ theme(text = element_text(size=10), axis.text.x = element_text(angle=60, hjust=1))
1125/5627 #19.99% of loan defaulters are from CA

ggplot(loan_chargedoff, aes(x = as.factor(int_rate_slot)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Interest Rate Slot", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
1627/5627 #28.91% of loan defaulters are in interest range of 13% to 16%
1579/5627 #28.06%  of loan defaulters are in interest range of >16%

ggplot(loan_chargedoff, aes(x = as.factor(annual_inc_slot)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Annual Income Slot", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
1999/5627 #35.5% of loan defaulters are earning in range of 25K to 50K
1741/5627 #30.94%  of loan defaulters are earning in range of 50K to 75K

ggplot(loan_chargedoff, aes(x = as.factor(loan_amount_slot)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Loan Amount Slot", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
1429/5627 #25.39% of loan defaulters have taken loan in range of 12K to 20K

# Let us Analyse the correlation of categorical variables on each other

# Let us start with Location
ggplot(loan_chargedoff, aes(x = as.factor(loan_chargedoff$addr_state), fill = term))+geom_bar(stat = "Count", position = "dodge") + labs(x = "Location", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_dodge(width = 1), size=2) + scale_fill_discrete(name = "Term")+ theme(text = element_text(size=10), axis.text.x = element_text(angle=45, hjust=1))
# It is evident that applicants from CA are major defaulters of loan, People taken loan for 36 months are major defaulters in CA

# Let us Analyse on employee length
ggplot(loan_chargedoff, aes(x = as.factor(emp_length), fill = term))+geom_bar(stat = "Count") + labs(x = "Employee Length", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_stack(vjust=1)) + scale_fill_discrete(name = "Term")

ELHO <- ggplot(loan_chargedoff, aes(x = as.factor(emp_length), fill = home_ownership))+geom_bar(stat = "Count", position="dodge") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_dodge(width=1)) + scale_fill_discrete(name = "Home Ownership")
ELHO + facet_wrap( ~ term, nrow =5, ncol = 1) + labs(x = "Employee Length", y = "Count of Loan Applications Defaulted")

ELVS <- ggplot(loan_chargedoff, aes(x = as.factor(emp_length), fill = verification_status))+geom_bar(stat = "Count", position = "dodge") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_dodge(width=1)) + scale_fill_discrete(name = "Verification Status")
ELVS + facet_wrap( ~ term, nrow =5, ncol = 1) + labs(x = "Employee Length", y = "Count of Loan Applications Defaulted")

ELHv <- ggplot(loan_chargedoff, aes(x = as.factor(emp_length), fill = loan_chargedoff$home_ownership))+geom_bar(stat = "Count", position = "dodge") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_dodge(width=1)) + scale_fill_discrete(name = "Home Ownership")
ELHv + facet_wrap( ~ verification_status, nrow =5, ncol = 1) + labs(x = "Employee Length", y = "Count of Loan Applications Defaulted")

# Following is our observation
# 1. Employee length with >10 years are more defaulters
# 2. Employee length with >10 Years and home ownership as Mortgage are major defaulters
# 3. People who are not verified and opted for 36 months of loan are more defaulters while people with 60 months of loan and verified are more defaulters

# Let us Analyse on Home Ownership
ggplot(loan_chargedoff, aes(x = as.factor(home_ownership), fill = verification_status))+geom_bar(stat = "Count") + labs(x = "Home Ownership", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_stack(vjust=0)) + scale_fill_discrete(name = "Verification Status")

HOVS <- ggplot(loan_chargedoff, aes(x = as.factor(home_ownership), fill = verification_status))+geom_bar(stat = "Count", position = "dodge") + geom_text(stat = 'count', aes(label = ..count..), vjust = -0.2, position = position_dodge(width=1)) + scale_fill_discrete(name = "Verification Status")
HOVS + facet_wrap( ~ term, nrow =5, ncol = 1) + labs(x = "Home Ownership", y = "Count of Loan Applications Defaulted")

HOIRS <- ggplot(loan_chargedoff, aes(x = as.factor(home_ownership), fill = int_rate_slot))+geom_bar(stat = "Count", position = "dodge") + geom_text(stat = 'count', aes(label = ..count..), vjust = -0.2, position = position_dodge(width=1)) + scale_fill_discrete(name = "Interest Rate")
HOIRS + facet_wrap( ~ term, nrow =5, ncol = 1) + labs(x = "Home Ownership", y = "Count of Loan Applications Defaulted")

# Following is our observations
# Home Ownership as Rent and Mortgage are high in defaulters
# For 36 months term, people on rent are more defaulters even if they are verified. People paying 13% to 16% interest are major defaulters
# for 60 months term, people with Mortgage home are more defaulters and are mostly not verified, people paying more than 16% are major defaulters

# Let us analyse based on purpose of taking the loan
ggplot(loan_chargedoff, aes(x = as.factor(loan_chargedoff$purpose), fill = term))+geom_bar(stat = "Count", position="dodge") + labs(x = "Purpose", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1,position = position_dodge(width=1)) + scale_fill_discrete(name = "Term")
PRIRS <- ggplot(loan_chargedoff, aes(x = as.factor(purpose), fill = int_rate_slot))+geom_bar(stat = "Count") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_stack(vjust=0), size=2) + scale_fill_discrete(name = "Interest Rate")
PRIRS + facet_wrap( ~ term, nrow =5, ncol = 1) + labs(x = "Purpose", y = "Count of Loan Applications Defaulted")
# Following is our observations
# 49.17% Applicants took loan due to debt_consolidation are defaulters
# For debt consolidation purpose loan term with 36 month and interest rate >16% are high in default
# For debt consolidation purpose loan term with 60 month and interest rate is in range of 13% to 16% are high in default

# Let us analyse based on grade of taking the loan
ggplot(loan_chargedoff, aes(x = as.factor(grade), fill = term))+geom_bar(stat = "Count") + labs(x = "Grade", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1, position = position_stack(vjust = 0.5)) + scale_fill_discrete(name = "Term")
GRVS <- ggplot(loan_chargedoff, aes(x = as.factor(grade), fill = verification_status))+geom_bar(stat = "Count", position = "dodge") + geom_text(stat = 'count', aes(label = ..count..), vjust = -0.2, position = position_dodge(width=1)) + scale_fill_discrete(name = "Verification Status")
GRVS + facet_wrap( ~ term, nrow =5, ncol = 1) + labs(x = "GRADE", y = "Count of Loan Applications Defaulted")
# Following are our observations
# Overall Grade B are more defaulters
# For 36 months loan, Grade B is major defaulters and Grade G is min defaulter. Grade A is mostly defaulted in 36 month term only
# For 60 months loan, Grade E and Grade D are major defaulters and Grade A is min defaulters. 


# Extracting the data in CSV file to compute graphs in Tableau for Presentation Purpose
write.csv(loan2, "loan_eda_analysis.csv")

### Assumptions and Recommendations are mentioned in PPT #################

########## Below are some more graphs plotted for Analysis but not used for presentation hence sharing them as comments #########


 
# ggplot(loan_chargedoff, aes(x = as.factor(grade), fill = term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1) + scale_fill_discrete(name = "Term")
# # It clearly shows that loan with grade B were max charged off specifically in 36 months terms followed by grade C, D and E type of loan
# 
# gradeB <- filter(loan2, grade == "B")
# ggplot(gradeB, aes(x = as.factor(sub_grade)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Sub Grade", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
# # Loan with Sub grade as B3 were max charged off followed by B5 and B4.
# 
# ggplot(loan_chargedoff, aes(x = as.factor(emp_length)))+geom_bar(stat = "Count", fill = "Blue") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1) + scale_fill_discrete(name = "Term")
# # Clearly shows that employees with 10+ years of experience are leaders in loan defaulters
# 
# ggplot(loan_chargedoff, aes(x = as.factor(home_ownership), fill = term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)+ scale_fill_discrete(name = "Term")
# # People who are staying on rent or has house mortage are leaders as defaulters. Max is people on rent and has 36 month of loan term
# 
# # important graph - need to remove overlapping
# ggplot(loan_chargedoff, aes(x = as.factor(emp_length), fill = home_ownership))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
# # this shows that guys with 10+ years of experience and has house mortage are major defaulters
# 
# ggplot(loan_chargedoff, aes(x = as.factor(verification_status), fill = term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)+ scale_fill_discrete(name = "Term")
# # this clearly shows that applicants applied for 36 months and are not verified are major defaulters(1652). While 1191 number of vertified consumers in 36 month duration are also defaulters
# 
# ggplot(loan_chargedoff, aes(x = as.factor(home_ownership), fill = verification_status))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)+ scale_fill_discrete(name = "Verification Status")
# # Applicants on rent / Mortgage and are not vertified are major count of people who charged off the loan ~ 37%
# 
# ggplot(loan_chargedoff, aes(x = as.factor(annual_inc_slot), fill = verification_status))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)+ scale_fill_discrete(name = "Verification Status")
# # Applicants with 25 to 50K are more in number as defaulters
# 
# #ggplot(loan_chargedoff, aes(x = as.factor(loan_chargedoff$annual_inc_slot), fill = loan_chargedoff$term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
# # Applicants in range of 25K to 50K are max defaulters, followed by applicants with income range of 50K to 75K
# 
# ggplot(loan_chargedoff, aes(x = as.factor(int_rate_slot), fill = term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
# # Loan with more than 13% interest rate is more likely to get into defaulter state
# 
# ggplot(loan_chargedoff, aes(x = as.factor(loan_amount_slot), fill = term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
# # Loan amount of 12k to 20K is more likely to get into defaulter state
# 
# ggplot(loan_chargedoff, aes(x = as.factor(addr_state), fill = term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)
# # Applicants from CA are more defaulters
# 
# 
# CA <- filter(loan_chargedoff, addr_state == "CA")
# ggplot(CA, aes(x=factor(zip_code)))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1)+ theme(text = element_text(size=10), axis.text.x = element_text(angle=45, hjust=1))
# # 945xx, 917xx, 926xx, 900xx
# 
# ggplot(loan_chargedoff, aes(x = as.factor(purpose), fill = loan_chargedoff$term))+geom_bar(stat = "Count") + labs(x = "Loan Status", y = "Count of Loan Applications Defaulted") + geom_text(stat = 'count', aes(label = ..count..), vjust = -1) + theme(text = element_text(size=10), axis.text.x = element_text(angle=45, hjust=1))
# # Loan taken for debt consolidation are more likely to be defaulters
# 
# # Boxplots for numerical data and remove outliers
# 
# ggplot(loan_chargedoff, aes(x = "", y=loan_amnt)) + geom_boxplot(outlier.colour="red",outlier.size=1)
# ggplot(loan_chargedoff, aes(x = emp_length, y=loan_amnt)) + geom_boxplot(outlier.colour="red",outlier.size=1)












# 
# G <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = loan2$grade))+geom_bar(position = "dodge")
# G + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Grade" )
# 
# V <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = loan2$verification_status))+geom_bar(position = "dodge")
# V + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Verification Status" )
# 
# H <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = loan2$home_ownership))+geom_bar(position = "dodge")
# H + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Home Ownership" )
# 
# E <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = loan2$emp_length)) +geom_bar(position = "dodge")
# E + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Emp Length" )
# 
# P <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = loan2$purpose)) +geom_bar(position = "dodge")
# P + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Purpose" )
# 
# I <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = as.factor(loan2$int_rate_slot))) +geom_bar(position = "dodge")
# I + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Interest Rate" )
# 
# A <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = as.factor(loan2$loan_amount_slot))) +geom_bar(position = "dodge")
# A + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Loan Amount" )
# 
# AA <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = as.factor(loan2$annual_inc_slot))) +geom_bar(position = "dodge")
# AA + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Annual Income" )
# 
# G1 <- ggplot(loan2, aes(x = as.factor(loan2$loan_amount_slot),fill = loan2$grade))+geom_bar(position = "dodge")
# G1 + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Loan Amount", y = "Number of Requests", fill = "Grade" )
# 
# V1 <- ggplot(loan2, aes(x = as.factor(loan2$loan_amount_slot),fill = loan2$verification_status))+geom_bar(position = "dodge")
# V1 + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Loan Amount", y = "Number of Requests", fill = "Verification Status" )
# 
# H1 <- ggplot(loan2, aes(x = as.factor(loan2$loan_amount_slot),fill = loan2$home_ownership))+geom_bar(position = "dodge")
# H1 + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Loan Amount", y = "Number of Requests", fill = "Home Ownership" )
# 
# E1 <- ggplot(loan2, aes(x = as.factor(loan2$loan_amount_slot),fill = loan2$emp_length)) +geom_bar(position = "dodge")
# E1 + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Loan Amount", y = "Number of Requests", fill = "Emp Length" )
# 
# P1 <- ggplot(loan2, aes(x = as.factor(loan2$loan_amount_slot),fill = loan2$purpose)) +geom_bar(position = "dodge")
# P1 + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Loan Amount", y = "Number of Requests", fill = "Purpose" )
# 
# I1 <- ggplot(loan2, aes(x = as.factor(loan2$loan_amount_slot),fill = as.factor(loan2$int_rate_slot))) +geom_bar(position = "dodge")
# I1 + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Loan Amount", y = "Number of Requests", fill = "Interest Rate" )
# # If the loan amount is above 12K and interest rate is above 16%, we find a spike in loan defaulters
# 
# AA1 <- ggplot(loan2, aes(x = as.factor(loan2$loan_amount_slot),fill = as.factor(loan2$annual_inc_slot))) +geom_bar(position = "dodge")
# AA1 + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Loan Amount", y = "Number of Requests", fill = "Annual Income" )
# # It seems some correlation between loan amount and annual income.
# 
# SG <- ggplot(loan2, aes(x = as.factor(loan2$term),fill = loan2$sub_grade))+geom_bar(position = "dodge")
# SG + facet_wrap( ~ loan2$loan_status, nrow =5, ncol = 1) + labs(x = "Term", y = "Number of Requests", fill = "Grade" )
# 






